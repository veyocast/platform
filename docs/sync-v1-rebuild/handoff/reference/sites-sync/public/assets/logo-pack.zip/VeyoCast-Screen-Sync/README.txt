VEYOCAST — SCREEN SYNC
Vector logo pack • 17 oktober 2026

Concept 06: twee overlappende schermen verbeelden gesynchroniseerde content op meerdere displays. Het logo is zorgvuldig opnieuw opgebouwd uit vectorpaden, op basis van het gekozen concept.

BESTANDEN
brand-icon.svg: beeldmerk in kleur.
icon-square.svg: beeldmerk met vierkante transparante ruimte voor apps en splashschermen.
icon-mono-dark.svg / icon-mono-light.svg: beeldmerk in één kleur.
wordmark-dark.svg / wordmark-light.svg: los woordmerk.
full-dark.svg / full-light.svg: horizontaal logo met donker respectievelijk licht woordmerk.
full-mono-dark.svg / full-mono-light.svg: horizontaal logo in één kleur.
stacked-dark.svg / stacked-light.svg: verticaal logo.
png/: transparante PNG-exports, minimaal 2048 px breed; horizontale logo's 4096 px breed.
preview.png: voorbeelden op een lichte en donkere achtergrond.
brand-reference.png: neutrale referentie voor vormgeving en de 3D-uitwerking.

KLEUREN
Sync Mint  #59E4B0
Deep Teal  #006D83
Ink        #0D1725
Cloud      #F6FBF9
Canvas     #F5F6F2

TYPOGRAFIE
Manrope, gewicht 500 voor Veyo en 700 voor Cast. Optisch aangepaste letterafstand.
Alle letters in de logo-SVG's zijn paden: geen fontinstallatie nodig, geen externe verwijzingen en geen ingesloten rasterafbeeldingen.
Voor interfacegebruik: Manrope 500 body, 600–700 titels. De originele variabele Latin WOFF2 is bijgevoegd onder fonts/, met SIL Open Font License 1.1.

GEBRUIK
Gebruik full-dark op lichte vlakken en full-light op donkere vlakken.
Houd rondom het logo minimaal de dikte van één schermframe vrij.
Behoud de verhoudingen; rek het logo niet uit.
Gebruik de monochrome varianten bij zeer kleine afmetingen of éénkleurendruk.
Alle logo-SVG's en PNG's in png/ hebben een transparante achtergrond. Alleen de expliciete voorbeeld- en referentiebestanden hebben een achtergrond.
