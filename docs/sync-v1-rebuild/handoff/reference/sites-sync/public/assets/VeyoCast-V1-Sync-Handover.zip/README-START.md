# VeyoCast — Sync V1 handover

Start bij source/docs/README-OVERDRACHT.md.

1. Bekijk het prototype: https://veyocast-v1-design-lab.dgwebserv.chatgpt.site/?design=sync
2. Bekijk de publieke marketingwebsite: https://veyocast.dgwebserv.chatgpt.site
3. Gebruik source/docs/V1-SYNC-CANON.md als productspecificatie.
4. Geef Codex source/docs/CODEX-BOUWPROMPT.md met de volledige source/ map.
5. Controleer source/docs/ACCEPTATIE.md en TESTRESULTATEN.md.

Alle code, gebruikte afbeeldingen, vectorlogo’s, fonts, licenties, buildconfiguratie en testbestanden zitten in source/. Dit is het definitieve Sync-prototype; de vier alternatieven zijn vervallen.

Lokaal: cd source, npm ci, npm run dev. Demo MFA: 123456. Pairing: VYO482. Externe diensten en devices zijn gesimuleerd; lokale wijzigingen blijven in de browser. De bestaande productieapp is niet gewijzigd.
